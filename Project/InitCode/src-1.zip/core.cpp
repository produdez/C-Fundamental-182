//
// Created by Nguyen Duc Dung on 2019-02-15.
//
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include "stdlib.h"
#include "string"
#include "stdio.h"
#include "fstream"
#include "sstream"
using namespace std;

/// Prototype declaration
//void wait(int seconds);
void Initialization();
void Finalization();

void LoadConfiguration();
void LoadMenu();
void DisplayMenu();
void ProcessUserChoice();
///--------------------------------------------------------------------

bool __coreInitialized = false;  /// an example of global variable
int  __userChoice;               /// a global variable to store user choice
bool __isExiting = false;        /// this variable should be turn on when the program exits
// TODO: add more global variables to complete tasks
string menu[5];
string intro[9];
string stringbb, h;

///--------------------------------------------------------------------
/**
 * Function: Initialization
 * Purpose:  Initialize anything necessary in your program before starting
 * Input:    None
 * Output:   None
 */
void Initialization() {
    LoadConfiguration();
    LoadMenu();
    // TODO: write the code to initialize the program
   __coreInitialized = true;
	__isExiting = false;
	__userChoice = -1; 
}

/**
 * Function: Finalization
 * Purpose:  Clean up everything before the program exits
 * Input:    None
 * Output:   None
 */
void Finalization() {
    // TODO: write the code to clean up when the program exits
	exit(EXIT_SUCCESS);
}



/*void wait(int seconds){
	clock_t endwait;
	endwait = clock() + seconds * CLOCKS_PER_SEC;
	while (clock() < endwait) {}
}*/


bool isInteger(string s)
{
   bool check;

std::istringstream iss(s);
if (iss.eof() == false)
    check = false;
else check = true;
return check;
}



void LoadConfiguration() {
    // TODO: write code to load data from the configuration file
	ifstream conf("conf.json", ios::in);
	conf.seekg(0, ios::beg);
	string wc = "WelcomeText";
	int count = 0, ps =0;
	while (getline(conf, h)) {
		count++;
	}
	conf.clear();
	conf.seekg(0, ios::beg);
	for (int i = 0; i < count; i++)
	{
		getline(conf, stringbb);
		if ((stringbb.find(wc) > 0) && (stringbb.find(wc) < stringbb.length()))
			ps = i;
	}
	conf.seekg(0, ios::beg);
	for (int i = 0; i < ps+1; i++)
		getline(conf, stringbb);
	for (int i = 0; i < 9; i++) {
		getline(conf, intro[i]);
		intro[i].erase(intro[i].begin(), intro[i].begin() + 14);
		if (i <= 7)
			intro[i].erase(intro[i].length() - 2, intro[i].length());
		else intro[i].erase(intro[i].length() - 1, intro[i].length());
	}
	conf.seekg(0, ios::beg);
	string timeintros;
	wc = "IntroTime";
	ps = 0;
	for (int i = 0; i < count; i++)
	{
		getline(conf, stringbb);
		if ((stringbb.find(wc) > 0) && (stringbb.find(wc) < stringbb.length()))
			ps = i;
	}
	conf.seekg(0, ios::beg);
	for (int i = 0; i < ps; i++)
		getline(conf, stringbb);
	getline(conf, timeintros);
	timeintros.erase(timeintros.begin(), timeintros.begin() + 14 + 1);
	timeintros.erase(timeintros.length() - 1, timeintros.length());
	int timeintro = atoi(timeintros.c_str());
	//wait(timeintro);
	conf.close();
}

void LoadMenu() {
    // TODO: write code to load menu from the configuration file
	for (int i = 0; i < 9; i++) {
		cout << intro[i] << endl;
	}
	ifstream conf("conf.json", ios::in);
	string wc = "Menu";
	int count = 0, ps = 0;
	while (getline(conf, h)) {
		count++;
	}
	conf.clear();
	conf.seekg(0, ios::beg);
	for (int i = 0; i < count; i++)
	{
		getline(conf, stringbb);
		if ((stringbb.find(wc) > 0) && (stringbb.find(wc) < stringbb.length()))
			ps = i;
	}
	conf.seekg(0, ios::beg);
	for (int i = 0; i < ps + 1; i++)
		getline(conf, stringbb);
	for (int i = 0; i < 5; i++) {
		getline(conf, menu[i]);
		menu[i].erase(menu[i].begin(), menu[i].begin() + 13);
		if (i <= 3)
			menu[i].erase(menu[i].length() - 2, menu[i].length());
		else menu[i].erase(menu[i].length() - 1, menu[i].length());
	}
	conf.close();
}

void DisplayMenu() {
    // TODO: Display the menu loaded from configuration file
	//cout << endl;
	for (int i = 0; i < 5; i++) {
		/*if (i != 1)*/
		cout << i + 1 << ". " << menu[i]<<endl;
		/*else 
			cout << i + 1 << ". " << "Log-in" << endl;*/
	}
}

/*bool IsNumber(string s, int n){
    if(n == 0) return false;
    //if(s[0] == '0') return false;
    if (s[1] == '+') return false;
    if (s[1] == '-') return false;
int diem=0;
for(int i = 0; i < n;i++){
if ((s[i] == ' ') && ( (s[i+1] >= '0' && s[i+1] <= '9')))
diem++;
}
if ((s[0]== ' ') && (diem != 1) )return false;
    for(int i = 0; i < n;i++){
        if((s[i] < '0' || s[i] > '9') && (s[i] != '+') && (s[i] != ' ')&& (s[i] != '-')) return false;
    }
    return true;
}*/

void ProcessUserChoice() {
    // TODO: Read user input and process
	char c;
	/*check:

		cin.clear();

		cout << "Please select: ";

		scanf("%d%c", &__userChoice, &c);
		if (!(c == '\n') || (__userChoice == -1)) {
			cin.clear();
			cout << "Invalid input, please input an integer number." << endl;
			//kt = true;
			cin.clear();
			cin.ignore(2000, '\n');
			goto check;
		}
		else if ((__userChoice > 5) || (__userChoice < 1)) {
			cout << "Please select a number from 1 to 5. " << endl;
			//kt = true;
			cin.clear();
			c = '\0';
			goto check;
		}
		*/




	/*bool kt = true;
	while (kt == true) {
	check:
		cin.clear();
		cout << "Please select: ";
		scanf_s("%d%c", &__userChoice, &c);
		if (!(c == '\n')) {
			cin.clear();
			cout << "Invalid input, please input an integer number." << endl;
			//kt = true;
			cin.clear();
			cin.ignore(2000, '\n');
			goto check;
		}
		else if ((__userChoice > 5) || (__userChoice < 1)) {
			cout << "Please select a number from 1 to 5. " << endl;
			//kt = true;
			cin.clear();
			c = NULL;
			goto check;
		}
		else {*/
			/*checkd :
				cout << "Please select: ";
				try {
					cin >> __userChoice;
				}
				catch (invalid_argument) {
					cout << "Invalid input, please input an integer number." << endl;
					//goto checkd;
				}*/

				/*string line;
			check:
				line = "\0";
				cout << "Please select: ";
				getline(cin, line);
int n = line.length();

				if (IsNumber(line, n) == false){
cout << "Invalid input, please input an integer number." << endl;
					goto check;
}
else {
if ((atof(line.c_str()) <= 5) && (atof(line.c_str()) >= 1))
					__userChoice = atof(line.c_str());
					else  

					{
						cout << "Please select a number from 1 to 5." << endl;

						goto check; 

					}
}

/*
				if (line == "\n") {
					cout << "Invalid input, please input an integer number." << endl;
					goto check;
				}
				for (int i = 0; i < line.length(); i++)
				{
					if (((line[i] < '0') || (line[i] > '9')) && (line[i] != '+') && (line[i] != ' ') && (line[i] != '-'))
					{
						cout << "Invalid input, please input an integer number." << endl;
						goto check;
						break;
					}
				}
				if ((atof(line.c_str()) && line != "\n"))
				{
					if ((atof(line.c_str()) <= 5) && (atof(line.c_str()) >= 1))
					__userChoice = atof(line.c_str());
					else  
					{
						cout << "Please select a number from 1 to 5." << endl;
						goto check; 
					}
				}
				else {
					cout << "Invalid input, please input an integer number." << endl;
					goto check;
				}*/

check:
string s; 
cout << "Please select: ";
				getline(cin, s);

/*
if (isInteger(s) == false) {
cout << "Invalid input, please input an integer number." << endl;
					goto check;
}
else{
__userChoice = atoi(s.c_str());
if ((__userChoice <0 ) || (__userChoice > 5)){
cout << "Please select a number from 1 to 5." << endl;

						goto check; 
}
}*/



s.erase(0,s.find_first_not_of(' '));
    if(s.length()==0)
    {
        cout << "Invalid input, please input an integer number." << endl;
					goto check;
    }
int diem = 0;
for (int i =0;i < s.length(); i++){
if ((s[i] >= '0') && ( s[i] <= '9') && ((s[i+1] == ' ') || (s[i+1] == '\0') ) ){
diem++;
}
}

if (diem > 1) {
cout << "Invalid input, please input an integer number." << endl;
					goto check;
} else {
for(int i=0; i<s.length(); i++)
    {
	if ((s[0] == '+' || s[0] == '-' ) && (s[1] == ' ')){
cout << "Invalid input, please input an integer number." << endl;
					goto check;
}
        if((i==0 && s.length()>1) && (s[0] == '+' || s[0] == '-' ) || (s[i] == ' '))
            continue;
        if(!isdigit(s[i]))
        {
            cout << "Invalid input, please input an integer number." << endl;
					goto check;
        }
    }
goto so;
}
/*tp=i;
break;
}
}
for (int j= tp+1; j < s.length(); j++)
if (s[j] != ' ') {
cout << "Invalid input, please input an integer number." << endl;
					goto check;
}
else if (s[j] == ' ') diem++;
if (diem == s.length()-tp) goto so;*/


    /*for(int i=0; i<s.length(); i++)
    {
        if((i==0 && s.length()>1) && (s[0] == '+' || s[0] == '-'))
            continue;
        if(!isdigit(s[i]))
        {
            cout << "Invalid input, please input an integer number." << endl;
					goto check;
        }
    }*/

so:
__userChoice = atoi(s.c_str());
if ((__userChoice <1 ) || (__userChoice > 5)){
cout << "Please select a number from 1 to 5." << endl;

						goto check; 
}


			switch (__userChoice)
			{
			case 1:
				cout << "You select menu item " << __userChoice << ". " << "Processing" << " . . . Done!" << endl;
				break;
			case 2:
				cout << "You select menu item " << __userChoice << ". " << "Processing" << " . . . Done!" << endl;
				break;
			case 3:
				cout << "You select menu item " << __userChoice << ". " << "Processing" << " . . . Done!" << endl;
				break;
			case 4:
				cout << "You select menu item " << __userChoice << ". " << "Processing" << " . . . Done!" << endl;
				break;
			case 5:
				cout << "Exiting..." << endl;
				__isExiting = true;
				//cin >> c;
				//_getch();
				//wait(1);
				//exit(0);
				break;
			}
			//kt = false;
		//}
	//}
}
